<footer class="footer">
    <div class="container-fluid">
        <p class="copyright pull-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            Design by <a href="http://www.creative-tim.com">Creative Tim</a>, and Developed by <a href="https://cipfahim.github.io/">Md.Aminul Islam Fahim</a>
        </p>
    </div>
</footer>